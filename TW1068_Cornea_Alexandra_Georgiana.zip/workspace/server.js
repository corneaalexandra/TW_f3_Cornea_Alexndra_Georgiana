var express = require("express")
var Sequelize = require("sequelize")
var nodeadmin = require("nodeadmin")
var cors = require("cors");
var bodyParser=require("body-parser");
var sequelize = new Sequelize('project', 'root', '', {
    dialect:'mysql',
    host:'localhost'
})
sequelize.authenticate().then(function(){
    console.log('Success')
})

var Locations = sequelize.define('Locations', {
    ID: Sequelize.INTEGER,
    Country: Sequelize.STRING,
    Town: Sequelize.STRING,
    Price: Sequelize.INTEGER
},{
    timestamps:false

})


var Clients = sequelize.define('Clients', {
    ID_client: {type: Sequelize.INTEGER, primaryKey: true},
    Name: Sequelize.STRING,
    Location_id: Sequelize.INTEGER,
},{
    
timestamps:false
    
})


Clients.belongsTo(Locations, {foreignKey: 'Location_id', targetKey: 'ID'})


//var app = express()

//app.use('/nodeamin', nodeadmin(app))

var app = express();
app.use('/nodeamin', nodeadmin(app));
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended:true
}));

app.use(cors());

app.get('/locations', function(request, response) {
    Locations.findAll().then(function(locations){
        response.status(200).send(locations)
    })
        
})

app.post('/locations', function(request, response) {
    Locations.create(request.body).then(function(location) {
        response.status(201).send(location)
    })
})

app.put('/locations/:id', function(request, response) {
    Locations.findById(request.params.id).then(function(location) {
        if(location) {
            location.update(request.body).then(function(location){
                response.status(201).send(location)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/locations/:id', function(request, response) {
    Locations.findById(request.params.id).then(function(location) {
        if(location) {
            location.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})


app.get('/clients', function(request, response) {
    Clients.findAll().then(function(clients){
        response.status(200).send(clients)
    })
        
})

app.post('/clients', function(request, response) {
    Clients.create(request.body).then(function(client) {
        response.status(201).send(client)
    })
})

app.put('/clients/:id', function(request, response) {
    Clients().findById(request.params.id).then(function(client) {
        if(client) {
            client.update(request.body).then(function(client){
                response.status(201).send(client)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/clients/:id', function(request, response) {
    Clients.findById(request.params.id).then(function(client) {
        if(client) {
            client.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})


app.listen(8080)